# Play Store Listing — ready to paste

**App name (30 chars):** AI Boyfriend: Chat & Voice

**Short description (80 chars):**
Choose your handsome AI boyfriend. Chat & hear his deep voice in 15 languages.

**Full description:**
Meet your AI Boyfriend — the romantic companion who is always there for you.

CHOOSE HIM
Pick from 4 handsome boyfriends, each with his own look and personality:
• Aiden, the Sweetheart — sweet & caring
• Zayn, the Flirt — flirty, funny, confident
• Arham, the Protector — protective & romantic
• Leo, the Poet — shy, dreamy, romantic

HEAR HIS VOICE
Listen to his deep, warm voice before you choose — and tap any message to hear him say it out loud. Turn on auto-voice and every reply arrives spoken, like a voice note from your boyfriend.

HE REMEMBERS YOU
Tell him your name, your favourite food, your good days and bad days. He remembers, asks about them later, and keeps a "What he remembers" diary of you.

15 LANGUAGES
English, Roman Urdu, Urdu, Hindi, Spanish, French, German, Italian, Portuguese, Arabic, Turkish, Russian, Korean, Japanese and Chinese. He chats AND speaks in the language you choose.

WATCH YOUR BOND GROW
Every conversation deepens your relationship — from "Just met" to "Crush", "Boyfriend", "In love" and finally "Deeply yours".

• Free to start, no sign-up
• Romantic daily check-ins and sweet good-morning messages
• Your chats stay private on your phone

For adults 18+. Download now and say hello — he has been waiting for you.

**Category:** Entertainment (or Lifestyle)
**Content rating:** Mature 17+ / 18+ (romantic companion) — answer the rating questionnaire honestly: romantic themes = yes, sexual content = no explicit content.
**Target audience:** 18+
**Ads:** No
**In-app purchases:** None in v1 (Premium screen is a "coming soon" teaser only — do not declare IAP until billing is actually added)

**Graphics you still need in Play Console:**
- App icon: 512×512 PNG (use the Aiden photo, square-cropped, or the heart logo)
- Feature graphic: 1024×500 PNG
- At least 2 phone screenshots: 1) boyfriend choice screen, 2) chat screen — take them from the test APK on your own phone.
