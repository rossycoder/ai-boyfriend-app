# Privacy Policy — AI Boyfriend

_Last updated: 11 November 2026_

AI Boyfriend ("the app") is a romantic AI companion for adults (18+).

## What we collect
- **Nothing is collected on our servers.** The app has no account system and no analytics.
- Your name, chosen boyfriend, language, chat history, bond points and "memories" are stored **only on your device** (app storage). Deleting the app deletes them.
- When you send a chat message, the message text is sent to our AI text provider (Pollinations) only to generate his reply. We do not store, sell, or share your messages.

## Permissions
- **Internet** — needed to generate AI replies and nothing else.
- The app does not access your contacts, photos, location, microphone, or camera.

## Children
The app is for adults only (18+). It is not directed at children.

## Contact
Questions: rozeena.careers031@gmail.com

> Play Store note: host this file as a web page (for example on GitHub Pages) and paste that URL into Play Console → Store settings → Privacy Policy.
