# AI Boyfriend — Flutter (Glass UI)

A complete Flutter app: glassmorphism UI, 4 handsome AI boyfriends with photos,
free AI chat (Pollinations, no API key), deep male voice (flutter_tts, low pitch + slow rate),
15 languages (chat + voice), on-device memory, and a bond/relationship meter.

## Screens
1. **Choose him** — glass cards, photo, personality, ▶ hear his voice first, your name, language picker (15), 18+ confirm
2. **Chat** — glass header + bond meter, glass bubbles for him, gradient bubbles for you, per-message 🔊, auto-voice toggle, quick chips, "What he remembers" bottom sheet
3. Data (name, history, memories, bond) persists on the phone via SharedPreferences

## Build it FREE in the cloud (no SDK on your PC)
1. Create a GitHub repo and push this folder.
2. GitHub → **Actions** tab → the build runs automatically.
3. Download the **ai-boyfriend-release** artifact:
   - `app-release.aab` → upload this to Play Store
   - `app-release.apk` → install on your own phone to test / take screenshots

## Or build locally
```
flutter create --org com.rozeena --project-name ai_boyfriend --platforms=android .
flutter pub get
flutter build appbundle --release
```

## Play Store upload — the honest checklist
1. **Play Console account: $25 one-time** — Google charges this to everyone; it needs a card that works for international online payment. (This is the only paid step, and only Rozeena can do it, in her own name.)
2. Verify your identity in Play Console (CNIC + address) — only you can do this.
3. Create app → upload `app-release.aab` → paste the listing from `STORE_LISTING.md`.
4. Privacy Policy URL: host `PRIVACY_POLICY.md` as a page (GitHub Pages works) and paste the link.
5. Content rating questionnaire + Data Safety form (answers are in the listing/privacy files: data stays on device; messages go to the AI provider to generate replies).
6. **New personal accounts:** Google requires a **closed test with 12+ testers for 14 days** before production goes live. Plan for this — it is normal, everyone new does it.
7. App signing: for production, create an upload keystore and add signing config before the final build (Play Console walks you through "Play App Signing").

Package: `com.rozeena.ai_boyfriend` · minSdk 24 · targetSdk 35 · v1.0.0

## v1.1 — what's new
- **Instagram-style DMs:** IG header (photo, verified tick, active status), IG bubbles, double-tap ❤️ reaction, long-press reaction picker (❤️😂😮😢🔥👍), "Seen", typing dots, camera/heart input bar
- **Emoji panel** built in + **GIFs:** he sends his animated selfie GIF as your bond grows; GIF button sends GIFs and he replies with hearts GIF
- **6 glass themes** (Midnight Purple, Rose Pink, Ocean Blue, Sunset, Emerald Night, Night Red) + auto Night theme after 10pm
- **His haal/mood line** changes all day (chai at work, evening walk, night mood...)
- **Roz good morning** in chat + **8am notification**, **10pm good night** (romantic night mood after 22:00)
- **Birthday wish** — set DOB at start; on the day he wishes first, with hearts GIF + voice
- **Angry handle** — if she's angry (gussa/naraz/angry words), he soothes, never argues
- **Period care** — optional tracker in the 🩷 Care sheet; on those days Care Mode: extra gentle, pain check-ins, rest reminders (on-device only, not medical advice)
- **Girls for boys** — start screen switch: Boyfriend (for girls) / Girlfriend (for boys): Aisha, Zara, Sofia, Mia with photos, female voices and their own GIFs
