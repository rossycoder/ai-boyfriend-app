# AI Partner — ProGuard/R8 keep rules (v1.8)
#
# Why this file exists:
# The Flutter Gradle plugin turns R8 minification ON for release app builds
# (even though the generated android/app/build.gradle template never sets
# minifyEnabled) and automatically picks up android/app/proguard-rules.pro.
# Gson 2.8.9 — bundled by flutter_local_notifications 17.2.x — ships NO
# consumer rules of its own, and the plugin's readme states the app must
# supply the Gson rules. Without them, R8 obfuscates Gson and strips the
# generic Signature metadata that Gson's TypeToken needs, so
# ScheduledNotificationBootReceiver crashes with
# RuntimeException "Missing type parameter." when it reloads the stored
# scheduled notifications after a reboot or a package update — and the
# daily 08:00 / 22:00 alarms can be lost.
#
# Rules below: Gson's official ProGuard example (google/gson,
# examples/android-proguard-example/proguard.cfg) plus the documented
# flutter_local_notifications keeps. The workflow copies this file to
# android/app/proguard-rules.pro and references it from the release
# buildType's proguardFiles.

# Gson: generic signatures + annotations MUST survive, otherwise
# TypeToken<T> loses its type argument at runtime.
-keepattributes Signature
-keepattributes *Annotation*
-keepattributes EnclosingMethod
-keepattributes InnerClasses
-dontwarn sun.misc.**

# Gson internals fully kept (names + members) — reflection-heavy library.
-keep class com.google.gson.** { *; }
-keep class * implements com.google.gson.TypeAdapter
-keep class * implements com.google.gson.TypeAdapterFactory
-keep class * implements com.google.gson.JsonSerializer
-keep class * implements com.google.gson.JsonDeserializer

# TypeToken and its subclasses: keep the class and its generic superclass
# (redundant while com.google.gson.** is fully kept, but this is the exact
# rule from Gson's official example that fixes "Missing type parameter.").
-keep,allowobfuscation,allowshrinking class com.google.gson.reflect.TypeToken
-keep,allowobfuscation,allowshrinking class * extends com.google.gson.reflect.TypeToken

# @SerializedName fields keep their names under obfuscation.
-keepclassmembers,allowobfuscation class * {
  @com.google.gson.annotations.SerializedName <fields>;
}

# flutter_local_notifications: plugin classes plus the model classes Gson
# (de)serializes by reflection when persisting scheduled notifications.
# (The plugin also ships its own consumer rules since 17.2.1+2; these are
# belt-and-braces so the receivers/models can never be stripped.)
-keep class com.dexterous.flutterlocalnotifications.** { *; }
-keep class com.dexterous.flutterlocalnotifications.models.** { *; }
