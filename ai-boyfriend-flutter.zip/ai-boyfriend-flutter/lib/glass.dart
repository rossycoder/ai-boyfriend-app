import 'dart:ui';
import 'package:flutter/material.dart';

/// Changeable glass themes — user picks in chat settings, saved on device.
class GlassTheme {
  final String name;
  final List<Color> gradient;
  final Color accentA;
  final Color accentB;
  final Color orb;
  const GlassTheme(this.name, this.gradient, this.accentA, this.accentB, this.orb);
}

const List<GlassTheme> kThemes = [
  GlassTheme('Midnight Purple', [Color(0xFF1B1035), Color(0xFF3B1150), Color(0xFF70163E), Color(0xFF12081F)], Color(0xFFFF4D8D), Color(0xFFB04DFF), Color(0x66FF4D8D)),
  GlassTheme('Rose Pink', [Color(0xFF2B0A1E), Color(0xFF5C1230), Color(0xFF9C1D4E), Color(0xFF1A0512)], Color(0xFFFF5C8A), Color(0xFFFF8FAB), Color(0x66FF5C8A)),
  GlassTheme('Ocean Blue', [Color(0xFF04182E), Color(0xFF0A2F52), Color(0xFF0E5A7A), Color(0xFF020E1A)], Color(0xFF38BDF8), Color(0xFF818CF8), Color(0x5538BDF8)),
  GlassTheme('Sunset', [Color(0xFF2A1206), Color(0xFF5A2410), Color(0xFF9C4A12), Color(0xFF180A02)], Color(0xFFFF9E57), Color(0xFFFF4D6D), Color(0x55FF9E57)),
  GlassTheme('Emerald Night', [Color(0xFF06231A), Color(0xFF0B3D2E), Color(0xFF116149), Color(0xFF03130D)], Color(0xFF34D399), Color(0xFF2DD4BF), Color(0x5534D399)),
  GlassTheme('Night Red', [Color(0xFF1F0505), Color(0xFF420A0A), Color(0xFF7A1010), Color(0xFF120202)], Color(0xFFFF3B3B), Color(0xFFFF7A59), Color(0x55FF3B3B)),
];

class ThemeStore {
  static int index = 0;
  static GlassTheme get current => kThemes[index.clamp(0, kThemes.length - 1)];
  static bool nightAuto = false; // after 22:00 we suggest Night Red
  static GlassTheme get active => nightAuto ? kThemes[5] : current;
}

class GlassBackground extends StatelessWidget {
  final Widget child;
  const GlassBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    final t = ThemeStore.active;
    return Stack(
      children: [
        Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: t.gradient),
          ),
        ),
        _Orb(size: 260, color: t.orb, top: -70, left: -60),
        _Orb(size: 220, color: t.orb.withOpacity(0.5), top: 240, left: 230),
        _Orb(size: 180, color: t.orb.withOpacity(0.4), top: 560, left: -40),
        SafeArea(child: child),
      ],
    );
  }
}

class _Orb extends StatelessWidget {
  final double size, top, left;
  final Color color;
  const _Orb({required this.size, required this.color, required this.top, required this.left});

  @override
  Widget build(BuildContext context) {
    return Positioned(
      top: top,
      left: left,
      child: Container(width: size, height: size, decoration: BoxDecoration(shape: BoxShape.circle, color: color)),
    );
  }
}

class GlassCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final double radius;
  final VoidCallback? onTap;
  const GlassCard({super.key, required this.child, this.padding = const EdgeInsets.all(16), this.radius = 24, this.onTap});

  @override
  Widget build(BuildContext context) {
    final card = ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(radius),
            color: Colors.white.withOpacity(0.12),
            border: Border.all(color: Colors.white.withOpacity(0.28), width: 1.2),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.25), blurRadius: 24, offset: const Offset(0, 10))],
          ),
          child: child,
        ),
      ),
    );
    if (onTap == null) return card;
    return Material(color: Colors.transparent, child: InkWell(borderRadius: BorderRadius.circular(radius), onTap: onTap, child: card));
  }
}

class GlassButton extends StatelessWidget {
  final String label;
  final VoidCallback? onTap;
  final IconData? icon;
  const GlassButton({super.key, required this.label, required this.onTap, this.icon});

  @override
  Widget build(BuildContext context) {
    final t = ThemeStore.active;
    return SizedBox(
      width: double.infinity,
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          gradient: LinearGradient(colors: [t.accentA, t.accentB]),
          boxShadow: [BoxShadow(color: t.accentA.withOpacity(0.45), blurRadius: 18, offset: const Offset(0, 8))],
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 15),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (icon != null) ...[Icon(icon, color: Colors.white, size: 20), const SizedBox(width: 8)],
                  Text(label, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
