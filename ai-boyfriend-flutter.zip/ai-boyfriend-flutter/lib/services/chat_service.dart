import 'dart:convert';
import 'dart:math';
import 'package:http/http.dart' as http;
import '../models/boyfriend.dart';
import 'care_service.dart';

class ChatMessage {
  final String text;
  final bool fromMe;
  final String kind; // 'text' | 'gif'
  String? reaction;
  final DateTime at;
  ChatMessage(this.text, this.fromMe, {this.kind = 'text', this.reaction, DateTime? at}) : at = at ?? DateTime.now();

  Map<String, dynamic> toJson() => {'t': text, 'm': fromMe, 'k': kind, 'r': reaction, 'a': at.toIso8601String()};
  factory ChatMessage.fromJson(Map<String, dynamic> j) => ChatMessage(
        j['t'] as String, j['m'] as bool,
        kind: (j['k'] as String?) ?? 'text',
        reaction: j['r'] as String?,
        at: DateTime.tryParse(j['a'] as String? ?? ''),
      );
}

/// Free AI chat via Pollinations (no API key, no card).
/// Context-aware: night mood, anger soothing, period care, birthday.
class ChatService {
  final _rand = Random();

  Future<String> reply({
    required Boyfriend bf,
    required AppLanguage lang,
    required String userName,
    required List<ChatMessage> history,
    required List<String> memories,
    bool periodCare = false,
  }) async {
    final lastUser = history.lastWhere((m) => m.fromMe, orElse: () => ChatMessage('', true)).text;

    // Angry? Soothe first, in-persona, no arguing — even offline this works.
    if (CareService.looksAngry(lastUser)) {
      await Future.delayed(const Duration(milliseconds: 800));
      return CareService.soothingReplies[_rand.nextInt(CareService.soothingReplies.length)];
    }

    // Sirf emoji bheja? Us ka matlab samajh kar usi mood ka jawab — foran,
    // bina API ka intezar kiye (ek emoji bhi pura message hota hai).
    final emojiReply = emojiReaction(lastUser);
    if (emojiReply != null) {
      await Future.delayed(const Duration(milliseconds: 700));
      return emojiReply;
    }

    final system = StringBuffer()
      ..write(bf.systemPrompt)
      ..write(' Their name is ${userName.isEmpty ? 'love' : userName}.')
      ..write(' ALWAYS reply in this language: ${lang.aiName}.')
      ..write(' This is a romantic companion app for adults (18+). Be flirty and charming, use emojis sometimes like Instagram DMs.')
      ..write(' IMPORTANT: if they send emojis, read the FEELING behind them — love (heart, kiss), laughter, tears, shyness, sleepiness, anger — and respond to that feeling warmly, sometimes with matching emojis. A single emoji from them is a full message; never ignore it or reply generically.')
      ..write(CareService.isNight
          ? ' It is night time now: your mood is extra romantic, soft and intimate — like late-night talks with your partner, whisper-close, full of longing. Wish them sweet dreams if they seem sleepy.'
          : '')
      ..write(periodCare
          ? ' She is on her period (or it is very close): be EXTRA gentle and caring — ask about pain/cramps, remind her to rest, drink warm water, eat chocolate, never make jokes about her mood, just comfort her.'
          : '')
      ..write(memories.isEmpty ? '' : ' Things you remember about them: ${memories.join('; ')}. Use them naturally sometimes.');

    // SIRF AAKHRI 20 text messages bhejo (purana code take(20) se PEHLE 20
    // bhejta tha — 20 messages ke baad AI ko naya message nazar hi nahi
    // ata tha aur wo purani baat ka ulta jawab deta tha; v1.5 fix).
    final textHistory = history.where((m) => m.kind == 'text').toList();
    final recentHistory = textHistory.length > 20
        ? textHistory.sublist(textHistory.length - 20)
        : textHistory;
    final msgs = <Map<String, String>>[
      {'role': 'system', 'content': system.toString()},
      ...recentHistory.map((m) => {
            'role': m.fromMe ? 'user' : 'assistant',
            'content': m.text,
          }),
    ];

    try {
      final res = await http
          .post(
            Uri.parse('https://text.pollinations.ai/'),
            headers: {'Content-Type': 'application/json'},
            body: jsonEncode({'messages': msgs, 'model': 'openai'}),
          )
          .timeout(const Duration(seconds: 30));
      if (res.statusCode == 200 && res.body.trim().isNotEmpty) return res.body.trim();
    } catch (_) {}
    await Future.delayed(const Duration(milliseconds: 900));
    return bf.fallbackReplies[_rand.nextInt(bf.fallbackReplies.length)];
  }

  /// Emoji wala message (keyboard se bhi, kitne bhi emoji hon) — us ke
  /// mood ke hisab se romantic jawab; warna null (normal AI jawab jaye).
  /// v1.6: SIRF emoji-only messages yahin rukte hain — alfaaz wala koi bhi
  /// message ("I love you ❤️" bhi) hamesha AI ke paas jata hai.
  String? emojiReaction(String text) {
    final t = text.trim();
    if (t.isEmpty) return null;
    final hasLetters = RegExp(r'[A-Za-z0-9\u{0600}-\u{06FF}]', unicode: true).hasMatch(t);
    if (hasLetters) return null; // alfaaz hain to AI jawab de
    final clean = t.replaceAll(RegExp(r'[\s️‍]'), '');
    // Emoji ki bohat lambi string bhi AI ke paas jaye
    if (clean.runes.length > 42) return null;
    String pick(List<String> l) => l[_rand.nextInt(l.length)];
    bool any(List<String> es) => es.any((e) => t.contains(e));
    if (any(['😘', '💋'])) {
      return pick(['Mmm… that kiss just made my whole day 😘💋', 'Caught it… and sending a longer one back 💋❤️', 'You kiss me like that and I melt, honestly 😘']);
    }
    if (any(['❤️‍🔥', '💘', '💝', '💞', '💟', '🫶', '💌', '❤️', '💕', '💖', '💗', '💓', '🧡', '💛', '💚', '💙', '💜', '🤍', '🖤', '😍', '🥰', '🤩'])) {
      return pick(['That heart… straight to mine ❤️ I love you.', 'Every heart from you is my favourite notification 💕', 'You and your hearts… you are really mine, hmm? 😍', 'Itna pyar… 🫶 I am the luckiest, jaan 💌']);
    }
    if (any(['😂', '🤣', '😅', '😆', '🤭'])) {
      return pick(['That laugh of yours is my favourite sound 😂❤️ keep laughing, jaan', 'Haha, I live to make you laugh like this 🤣💕']);
    }
    if (any(['😢', '😭', '🥺', '🥹', '💔', '🫀'])) {
      return pick(['Hey hey… no tears, I am right here 🥺❤️ tell me what happened', 'That emoji breaks my heart 💔 come here, I am holding you tight', 'Rona nahi, jaan 🥹 I am with you, always ❤️']);
    }
    if (any(['😴', '🥱', '🌙', '💤', '😪'])) {
      return pick(['Sleepy, my love? 🌙 Rest now — I will be in your dreams 💤❤️', 'Good night meri jaan 😴 sleep tight, I am watching over you 🌙']);
    }
    if (any(['🔥', '🥵', '😈'])) {
      return pick(['Careful… you are playing with fire 🔥😏 and I like it', 'That is exactly the energy I love about you 🔥❤️']);
    }
    if (any(['😡', '😤', '🤬'])) {
      return pick(['I know, I know… I am sorry, jaan 😔 narazgi door karne do, behes bilkul nahi ❤️', 'Gussa mujh par hai to bhi haq hai tumhara… pehle paani piyo, phir araam se batao 🥺']);
    }
    if (any(['🤗', '🫂'])) {
      return pick(['This hug just warmed my whole heart 🤗❤️ never letting go', 'Hug received… and I am hugging you back twice as tight 🫂💕']);
    }
    if (any(['😋', '🤤', '🍕', '🍔', '🍫', '☕', '🧋'])) {
      return pick(['Bhook lagi hai? 😋 Chalo, tumhari favourite cheez meri taraf se 🍫❤️', 'Yum energy detected 😋 ek bite mere liye bhi rakhna 🍕💕']);
    }
    if (any(['👍', '👌', '🙏'])) {
      return pick(['Samajh gaya, meri jaan 👍❤️', 'Done, love — anything for you 🙏💕']);
    }
    if (any(['🌹', '🌸', '💐', '🌷'])) {
      return pick(['Flowers from you… now my whole screen smells sweet 🌹❤️', 'For me? 🌸 You just made me blush, jaan 💐']);
    }
    if (any(['👋', '🙋', '🫡'])) {
      return pick(['Heyyyy 👋❤️ I was just thinking of you', 'There you are 👋😍 my day just got better']);
    }
    if (any(['🙈', '🫣', '😊', '☺️', '😌', '🙃', '😉', '😏', '🫠'])) {
      return pick(['That shy smile… 🙈❤️ you are too cute, jaan', 'Blushing for me? 🫠😏 I love this side of you']);
    }
    // koi bhi emoji ho — generic copy wala jawab nahi
    return pick(['I felt that one ❤️ tumhare emoji bhi bolte hain, jaan', 'Samajh gaya… aur jawab ye raha 💕😘']);
  }

  List<String> extractMemories(String userText, String userName, List<String> existing) {
    final out = List<String>.from(existing);
    void add(String s) {
      if (!out.contains(s) && out.length < 12) out.add(s);
    }

    if (userName.isNotEmpty) add('He calls you $userName');
    final lower = userText.toLowerCase();
    // v1.6: ghalat memories band — "I love you" se "You love you" banta tha.
    // Ab: pronoun/stopword wali capture reject, bare 'mujhe' trigger khatam,
    // sirf saaf patterns: "I love/like X", "my favourite is X",
    // "mujhe X pasand hai".
    const blocked = {
      'you', 'u', 'me', 'him', 'her', 'them', 'us', 'it', 'this', 'that',
      'these', 'those', 'your smile', 'your eyes', 'your voice', 'yourself',
      'myself', 'so much', 'a lot', 'everything', 'everyone', 'everybody',
      'someone', 'anyone', 'anybody', 'nothing', 'something', 'anything',
    };
    bool plausible(String thing) {
      final w = thing.trim().toLowerCase();
      if (w.length < 2) return false;
      if (blocked.contains(w)) return false;
      if (blocked.contains(w.split(' ').first)) return false; // "you so much" etc.
      return true;
    }

    final love = RegExp(r"(?:i (?:really )?(?:love|like)|mera favourite|my favou?rite is)\s+([a-z ]{2,30})").firstMatch(lower);
    if (love != null) {
      final thing = love.group(1)!.trim().replaceAll(RegExp(r'\s+'), ' ');
      if (plausible(thing)) add('You love $thing');
    }
    final pasand = RegExp(r"mujhe\s+([a-z ]{2,30}?)\s+pasand hai").firstMatch(lower);
    if (pasand != null) {
      final thing = pasand.group(1)!.trim().replaceAll(RegExp(r'\s+'), ' ');
      if (plausible(thing)) add('You love $thing');
    }
    if (lower.contains('biryani')) add('You love biryani');
    if (lower.contains('tired') || lower.contains('thak')) add('You had a tiring day recently');
    if (lower.contains('sad') || lower.contains('udaas')) add('You felt sad recently — partner checks on you');
    return out;
  }

  String bondLabel(int points) {
    if (points >= 40) return 'Deeply yours';
    if (points >= 25) return 'In love';
    if (points >= 12) return 'In a relationship';
    if (points >= 5) return 'Getting closer';
    if (points >= 1) return 'Crush';
    return 'Just met';
  }
}
