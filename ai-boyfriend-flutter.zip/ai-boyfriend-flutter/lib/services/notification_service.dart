import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

/// Daily local notifications — no server needed:
/// 08:00 good morning from him/her, 22:00 good night (night mood).
/// Wrapped in try/catch everywhere: if the device denies permission, the app still works.
class NotificationService {
  static final _plugin = FlutterLocalNotificationsPlugin();
  static bool _ready = false;

  static Future<void> initAndSchedule(String partnerName, String userName) async {
    try {
      tzdata.initializeTimeZones();
      // Device ka asal timezone set karo — warna tz.local UTC rehta hai aur
      // 08:00 wali notification 13:00 PKT par bajti hai (v1.6 fix).
      try {
        final localTz = await FlutterTimezone.getLocalTimezone();
        tz.setLocalLocation(tz.getLocation(localTz));
      } catch (_) {
        // timezone na mile to UTC fallback — notifications phir bhi schedule hongi
      }
      const android = AndroidInitializationSettings('@mipmap/ic_launcher');
      await _plugin.initialize(const InitializationSettings(android: android));
      await _plugin
          .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
          ?.requestNotificationsPermission();
      _ready = true;
      // v1.8 self-heal: stored scheduled notifications ki list pehle
      // validate karo, phir dono daily alarms har launch par dobara
      // (idempotent) schedule karo — taake reboot ya app update ke baad
      // boot receiver fail bhi ho jaye to alarms wapas lag jayein.
      await _healStoredNotifications();
      await _daily(
        id: 1,
        hour: 8,
        title: 'Good morning ❤️',
        body: '$partnerName: Uth jao, $userName... din ki sab se pehli smile tumhare liye. ☀️',
      );
      await _daily(
        id: 2,
        hour: 22,
        title: 'Good night 🌙',
        body: '$partnerName: Aankhein band karo, fikrein mujh par chhor do. Sweet dreams, love.',
      );
    } catch (_) {
      _ready = false;
    }
  }

  /// Plugin ki stored scheduled-notification list ko parhne ki koshish.
  /// Purane release builds (v1.6/v1.7) me R8 ne Gson ki generic type info
  /// strip kar di thi, jis se ye stored list parhte waqt native side par
  /// "Missing type parameter" crash hota tha. Agar read fail ho to
  /// cancelAll() se kharab stored state saaf kar do — ye function kabhi
  /// throw nahi karta, is liye corrupted list startup ko crash nahi kar
  /// sakti, aur neeche wale _daily calls saaf slate par alarms lagate hain.
  static Future<void> _healStoredNotifications() async {
    try {
      await _plugin.pendingNotificationRequests();
    } catch (_) {
      try {
        await _plugin.cancelAll();
      } catch (_) {
        // Cancel bhi fail ho jaye to bhi aage barho: _daily ke zonedSchedule
        // calls same IDs (1, 2) par hain, jo purani entries ko replace kar
        // dete hain — alarms phir bhi sahi lag jayenge.
      }
    }
  }

  static Future<void> _daily({required int id, required int hour, required String title, required String body}) async {
    if (!_ready) return;
    // Har alarm apne try/catch me: ek fail ho to dusra phir bhi schedule ho.
    try {
      final now = tz.TZDateTime.now(tz.local);
      var when = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour);
      if (when.isBefore(now)) when = when.add(const Duration(days: 1));
      await _plugin.zonedSchedule(
        id,
        title,
        body,
        when,
        const NotificationDetails(
          android: AndroidNotificationDetails('daily_love', 'Daily love notes', importance: Importance.high, priority: Priority.high),
        ),
        androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
        uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        matchDateTimeComponents: DateTimeComponents.time,
      );
    } catch (_) {
      // Ek daily alarm ka fail hona dusre ko nahi rokta.
    }
  }
}
