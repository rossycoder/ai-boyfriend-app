import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

/// Daily local notifications — no server needed:
/// 08:00 good morning from him/her, 22:00 good night (night mood).
/// Wrapped in try/catch everywhere: if the device denies permission, the app still works.
class NotificationService {
  static final _plugin = FlutterLocalNotificationsPlugin();
  static bool _ready = false;

  static Future<void> initAndSchedule(String partnerName, String userName) async {
    try {
      tzdata.initializeTimeZones();
      const android = AndroidInitializationSettings('@mipmap/ic_launcher');
      await _plugin.initialize(const InitializationSettings(android: android));
      await _plugin
          .resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()
          ?.requestNotificationsPermission();
      _ready = true;
      await _daily(
        id: 1,
        hour: 8,
        title: 'Good morning ❤️',
        body: '$partnerName: Uth jao, $userName... din ki sab se pehli smile tumhare liye. ☀️',
      );
      await _daily(
        id: 2,
        hour: 22,
        title: 'Good night 🌙',
        body: '$partnerName: Aankhein band karo, fikrein mujh par chhor do. Sweet dreams, love.',
      );
    } catch (_) {
      _ready = false;
    }
  }

  static Future<void> _daily({required int id, required int hour, required String title, required String body}) async {
    if (!_ready) return;
    final now = tz.TZDateTime.now(tz.local);
    var when = tz.TZDateTime(tz.local, now.year, now.month, now.day, hour);
    if (when.isBefore(now)) when = when.add(const Duration(days: 1));
    await _plugin.zonedSchedule(
      id,
      title,
      body,
      when,
      const NotificationDetails(
        android: AndroidNotificationDetails('daily_love', 'Daily love notes', importance: Importance.high, priority: Priority.high),
      ),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }
}
