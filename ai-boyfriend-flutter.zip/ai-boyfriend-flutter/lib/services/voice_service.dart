import 'package:flutter_tts/flutter_tts.dart';
import '../models/boyfriend.dart';

/// Device ki text-to-speech awaz — theek shuda version:
/// - Sahi awaz chunta hai: pehle selected language ki awazain, un me se
///   boyfriend ke liye mardana / girlfriend ke liye female naam wali.
/// - Pitch/rate NATURAL rakha hai: pehle wala 0.65 pitch + 0.38 rate
///   bohot bhaari aur slow tha, is liye awaz ajeeb lagti thi.
class VoiceService {
  final FlutterTts _tts = FlutterTts();
  String? _voiceKey;

  static const _femaleNames = [
    'samantha', 'victoria', 'karen', 'moira', 'fiona', 'zira', 'veena',
    'lekha', 'heera', 'priya', 'susan', 'catherine', 'joana', 'maria',
    'elena', 'lucia', 'female', 'woman', 'alice', 'allison', 'ava',
    'kate', 'serena', 'tessa', 'milena', 'kyoko', 'yuna', 'nicky',
  ];
  static const _maleNames = [
    'daniel', 'david', 'george', 'arthur', 'brian', 'ravi', 'male',
    'alex', 'fred', 'tom', 'aaron', 'gordon', 'oliver', 'ryan',
    'james', 'john', 'hemant', 'man', 'boy',
  ];

  double _pitchFor(Boyfriend bf) {
    if (bf.isGirl) return bf.voicePitch.clamp(1.04, 1.16).toDouble();
    // 0.65..0.85 (purana gehra scale) -> 0.90..0.96 (natural halka gehra)
    return (0.90 + (bf.voicePitch - 0.65) * 0.3).clamp(0.88, 0.98).toDouble();
  }

  bool _nameHas(Map v, List<String> hints, String gender) {
    final n = (v['name'] ?? '').toString().toLowerCase();
    final g = (v['gender'] ?? '').toString().toLowerCase();
    if (g == gender) return true;
    return hints.any((h) => n.contains(h));
  }

  Future<void> _pickVoice(Boyfriend bf, AppLanguage lang) async {
    final key = '${bf.id}|${lang.ttsCode}';
    if (_voiceKey == key) return;
    _voiceKey = key;
    try {
      final raw = await _tts.getVoices;
      if (raw is! List) return;
      final voices = raw.whereType<Map>().toList();
      if (voices.isEmpty) return;
      final prefix = lang.ttsCode.split('-').first.toLowerCase();
      var pool = voices.where((v) {
        return (v['locale'] ?? '').toString().toLowerCase().startsWith(prefix);
      }).toList();
      if (pool.isEmpty) pool = voices;
      final want = bf.isGirl ? _femaleNames : _maleNames;
      final avoid = bf.isGirl ? _maleNames : _femaleNames;
      final gender = bf.isGirl ? 'female' : 'male';
      Map? chosen;
      for (final v in pool) {
        if (_nameHas(v, want, gender)) { chosen = v; break; }
      }
      if (chosen == null) {
        for (final v in pool) {
          if (!_nameHas(v, avoid, bf.isGirl ? 'male' : 'female')) { chosen = v; break; }
        }
      }
      chosen ??= pool.first;
      await _tts.setVoice({
        'name': (chosen['name'] ?? '').toString(),
        'locale': (chosen['locale'] ?? lang.ttsCode).toString(),
      });
    } catch (_) {}
  }

  Future<void> speak(String text, Boyfriend bf, AppLanguage lang) async {
    try {
      await _tts.setLanguage(lang.ttsCode);
      await _pickVoice(bf, lang);
      await _tts.setPitch(_pitchFor(bf));
      await _tts.setSpeechRate(0.5); // natural speed (purana 0.38-0.46 ajeeb slow tha)
      await _tts.setVolume(1.0);
      await _tts.stop();
      final clean = text.replaceAll(
          RegExp(r'[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]', unicode: true), '');
      await _tts.speak(clean);
    } catch (_) {}
  }

  Future<void> stop() async {
    try {
      await _tts.stop();
    } catch (_) {}
  }
}
