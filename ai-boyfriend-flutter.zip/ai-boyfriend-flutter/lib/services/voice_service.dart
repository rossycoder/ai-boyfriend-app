import 'package:flutter_tts/flutter_tts.dart';
import '../models/boyfriend.dart';

/// Deep, warm "sexy" male voice: low pitch + slow rate, in the chosen language.
class VoiceService {
  final FlutterTts _tts = FlutterTts();
  bool _ready = false;

  Future<void> _init(Boyfriend bf, AppLanguage lang) async {
    await _tts.setLanguage(lang.ttsCode);
    await _tts.setPitch(bf.voicePitch); // 0.65–0.85 = deep male
    await _tts.setSpeechRate(bf.voiceRate); // slow & warm
    await _tts.setVolume(1.0);
    // Try to pick a male voice when the device exposes voice names.
    try {
      final voices = await _tts.getVoices;
      if (voices is List) {
        for (final v in voices) {
          final name = (v['name'] ?? '').toString().toLowerCase();
          final locale = (v['locale'] ?? '').toString().toLowerCase();
          if (locale.startsWith(lang.ttsCode.split('-').first) &&
              (name.contains('male') || name.contains('david') || name.contains('daniel') || name.contains('george'))) {
            await _tts.setVoice({'name': v['name'], 'locale': v['locale']});
            break;
          }
        }
      }
    } catch (_) {}
    _ready = true;
  }

  Future<void> speak(String text, Boyfriend bf, AppLanguage lang) async {
    if (!_ready) await _init(bf, lang);
    await _tts.setLanguage(lang.ttsCode);
    await _tts.setPitch(bf.voicePitch);
    await _tts.setSpeechRate(bf.voiceRate);
    await _tts.stop();
    await _tts.speak(text.replaceAll(RegExp(r'[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]', unicode: true), ''));
  }

  Future<void> stop() => _tts.stop();
}
