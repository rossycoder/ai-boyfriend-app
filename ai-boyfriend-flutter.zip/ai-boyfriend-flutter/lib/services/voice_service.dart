import 'package:flutter_tts/flutter_tts.dart';
import '../models/boyfriend.dart';

/// Device ki text-to-speech awaz — theek shuda version:
/// - Sahi awaz chunta hai: pehle selected language ki awazain, un me se
///   boyfriend ke liye mardana / girlfriend ke liye female naam wali.
/// - Pitch/rate NATURAL rakha hai: pehle wala 0.65 pitch + 0.38 rate
///   bohot bhaari aur slow tha, is liye awaz ajeeb lagti thi.
class VoiceService {
  final FlutterTts _tts = FlutterTts();
  String? _voiceKey;

  static const _femaleNames = [
    'samantha', 'victoria', 'karen', 'moira', 'fiona', 'zira', 'veena',
    'lekha', 'heera', 'priya', 'susan', 'catherine', 'joana', 'maria',
    'elena', 'lucia', 'female', 'woman', 'alice', 'allison', 'ava',
    'kate', 'serena', 'tessa', 'milena', 'kyoko', 'yuna', 'nicky',
  ];
  static const _maleNames = [
    'daniel', 'david', 'george', 'arthur', 'brian', 'ravi', 'male',
    'alex', 'fred', 'tom', 'aaron', 'gordon', 'oliver', 'ryan',
    'james', 'john', 'hemant', 'man', 'boy',
  ];

  double _pitchFor(Boyfriend bf) {
    if (bf.isGirl) return bf.voicePitch.clamp(1.04, 1.16).toDouble();
    // 0.65..0.85 (purana gehra scale) -> 0.90..0.96 (natural halka gehra)
    return (0.90 + (bf.voicePitch - 0.65) * 0.3).clamp(0.88, 0.98).toDouble();
  }

  bool _nameHas(Map v, List<String> hints, String gender) {
    final n = (v['name'] ?? '').toString().toLowerCase();
    final g = (v['gender'] ?? '').toString().toLowerCase();
    if (g == gender) return true;
    return hints.any((h) => n.contains(h));
  }

  Future<void> _pickVoice(Boyfriend bf, AppLanguage lang) async {
    final key = '${bf.id}|${lang.ttsCode}';
    if (_voiceKey == key) return;
    // _voiceKey ABHI set nahi karte — pehle empty result a jaye to cache jal
    // jata tha aur poora session voice picking dobara try nahi hoti thi.
    // Key sirf tab set hogi jab awaaz asal me choose ho jaye (v1.6 fix).
    try {
      final raw = await _tts.getVoices;
      if (raw is! List) return;
      final voices = raw.whereType<Map>().toList();
      if (voices.isEmpty) return;
      final prefix = lang.ttsCode.split('-').first.toLowerCase();
      var pool = voices.where((v) {
        return (v['locale'] ?? '').toString().toLowerCase().startsWith(prefix);
      }).toList();
      if (pool.isEmpty) pool = voices;
      final want = bf.isGirl ? _femaleNames : _maleNames;
      final avoid = bf.isGirl ? _maleNames : _femaleNames;
      final gender = bf.isGirl ? 'female' : 'male';
      Map? chosen;
      for (final v in pool) {
        if (_nameHas(v, want, gender)) { chosen = v; break; }
      }
      if (chosen == null) {
        for (final v in pool) {
          if (!_nameHas(v, avoid, bf.isGirl ? 'male' : 'female')) { chosen = v; break; }
        }
      }
      chosen ??= pool.first;
      await _tts.setVoice({
        'name': (chosen['name'] ?? '').toString(),
        'locale': (chosen['locale'] ?? lang.ttsCode).toString(),
      });
      _voiceKey = key; // awaaz asal me set ho gayi — ab cache karo
    } catch (_) {}
  }

  /// TTS language set karo; device par wo voice na ho to khamoshi ke bajaye
  /// fallback chain: requested → (Urdu ke liye pehle Hindi) → en-US (v1.6 fix).
  Future<void> _setLanguageWithFallback(String code) async {
    final chain = <String>[code];
    if (code.toLowerCase().startsWith('ur')) chain.add('hi-IN');
    chain.add('en-US');
    for (final c in chain) {
      try {
        final avail = await _tts.isLanguageAvailable(c);
        if (avail == true || avail == 1) {
          await _tts.setLanguage(c);
          return;
        }
      } catch (_) {}
    }
    // Kuch bhi available report na ho to bhi requested hi try kar lo
    try {
      await _tts.setLanguage(code);
    } catch (_) {}
  }

  Future<void> speak(String text, Boyfriend bf, AppLanguage lang) async {
    try {
      await _setLanguageWithFallback(lang.ttsCode);
      await _pickVoice(bf, lang);
      await _tts.setPitch(_pitchFor(bf));
      // Har companion ki apni speed — pehle hardcoded 0.5 tha (v1.6 fix)
      await _tts.setSpeechRate(bf.voiceRate.clamp(0.3, 0.7).toDouble());
      await _tts.setVolume(1.0);
      await _tts.stop();
      final clean = text.replaceAll(
          RegExp(r'[\u{1F300}-\u{1FAFF}\u{2600}-\u{2BFF}\u{200D}\u{FE0F}]', unicode: true), '');
      await _tts.speak(clean);
    } catch (_) {}
  }

  Future<void> stop() async {
    try {
      await _tts.stop();
    } catch (_) {}
  }
}
