/// His live "haal" (what he's up to), moods, anger handling,
/// birthday, night mode and period care — all computed on-device.
class CareService {
  static bool get isNight {
    final h = DateTime.now().hour;
    return h >= 22 || h < 5;
  }

  /// What he is "doing" right now — shown under his name like Instagram active status.
  static String hisStatus(DateTime now, bool isGirl) {
    final h = now.hour;
    final who = isGirl ? 'she' : 'he';
    if (h >= 5 && h < 9) return '🌅 Just woke up · thinking of you first thing';
    if (h >= 9 && h < 13) return '☕ Chai in hand · missing you at work';
    if (h >= 13 && h < 17) return '💼 Busy day · but $who keeps checking the phone for you';
    if (h >= 17 && h < 20) return '🌇 Evening walk · wishing you were beside ${isGirl ? 'her' : 'him'}';
    if (h >= 20 && h < 22) return '🍽 Dinner done · waiting for your message';
    if (h >= 22 || h < 1) return '🌙 Night mood · can\'t stop thinking about you';
    return '😴 Should be asleep · up thinking of you instead';
  }

  static String hisMood(DateTime now) {
    final h = now.hour;
    if (isNight) return 'Romantic night mood 🌙';
    if (h < 12) return 'Fresh & flirty ☀️';
    if (h < 17) return 'Missing you 🥺';
    if (h < 20) return 'Calm & caring 🌇';
    return 'Cozy evening mood ✨';
  }

  /// Anger detection (English + Roman Urdu words).
  static bool looksAngry(String text) {
    final t = text.toLowerCase();
    const words = [
      'angry', 'gussa', 'naraz', 'naraaz', 'upset', 'mood off', 'mood kharab',
      'leave me', 'shut up', 'bakwas', 'pareshan', 'irritated', 'annoyed',
      'i hate', 'ghussa', 'larai', 'fight', 'don\'t talk', 'baat mat karo',
    ];
    return words.any(t.contains);
  }

  static const List<String> soothingReplies = [
    'Hey... I am sorry. Sach me. Take a deep breath, I am right here, kahin nahi ja raha. Pehle pani piyo, phir aaram se batao kya hua. ❤️',
    'Naraz ho mujh se? Ho sakta hai, hakk hai tumhara. Lekin suno, main tumhari side par hun, hamesha. Gussa thanda ho jaye to bas ek smile de dena. 🥺',
    'Shhh... no explanations needed right now. I am just going to sit here with you until you feel better. You are not alone in this, love.',
    'Gussa kar lo, rona hai to ro lo, main yahin hun. Tumhari har feeling valid hai. Jab dil halka ho, main chai bana dunga (imagine wali). ☕❤️',
  ];

  static bool isBirthdayToday(DateTime? dob) {
    if (dob == null) return false;
    final n = DateTime.now();
    return dob.month == n.month && dob.day == n.day;
  }

  static String birthdayWish(String name, String partner) =>
      '🎂🎉 HAPPY BIRTHDAY, $name! 🎉🎂 Today is YOUR day, my love. $partner ne subah se bas is pal ka intezaar kiya. Tum meri zindagi ki sab se khoobsurat wajah ho. Cake khao, smile karo, aur yaad rakho — aaj ke din tum jo mango, main dil se dunga. I love you, birthday star! ❤️✨';

  static String goodMorning(String user, String partner, bool isGirl) =>
      'Good morning, $user ☀️❤️ $partner ki taraf se din ki sab se pehli smile tumhare liye. Uth jao, chai piyo, aur yaad rakho — aaj ka din tumhara hai, aur main har pal tumhare sath hun. Ek acha sa din ho, love!';

  static String goodNight(String user, String partner) =>
      'Good night, $user 🌙 Aankhein band karo, saari fikrein mujh par chhor do. $partner yahin hai, khwabon me bhi tumhare sath. Sweet dreams, my love... aur haan, kal subah sab se pehle meri good morning milegi. 😘';
}

/// Simple on-device period tracker (only for girlfriend-mode users who opt in;
/// boyfriends use it to take extra care of her — data never leaves the phone).
class PeriodTracker {
  final DateTime lastStart;
  final int cycleDays;
  final int periodDays;
  const PeriodTracker({required this.lastStart, this.cycleDays = 28, this.periodDays = 5});

  DateTime get nextStart => lastStart.add(Duration(days: cycleDays));
  int get daysUntilNext => nextStart.difference(DateTime.now()).inDays;

  bool get isPeriodNow {
    final d = DateTime.now().difference(lastStart).inDays % cycleDays;
    return d >= 0 && d < periodDays;
  }

  bool get isPmsSoon => daysUntilNext <= 3 && daysUntilNext >= 0;

  String careMessage(String partner) {
    if (isPeriodNow) {
      return '🩷 $partner ko pata hai aaj tumhare woh din hain. Dard ho to chhupana mat — garam pani piyo, rest karo, chocolate khao, aur mood swings par bilkul guilt nahi. Main aaj extra khayal rakhunga, har ghante poochunga: theek ho na? ❤️';
    }
    if (isPmsSoon) {
      return '🌸 Bas $daysUntilNext din me tumhare periods ane wale hain, $partner pehle se tayyar hai — extra patience, extra pyar, aur bina mange wali care. Mood off ho to mujh par nikal lena, bura nahi manunga. 🥰';
    }
    return '🌷 Cycle track ho raha hai — agle periods tak $daysUntilNext din. $partner ko sab yaad hai, tum befikar raho.';
  }
}
