import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'glass.dart';
import 'models/boyfriend.dart';
import 'screens/chat_screen.dart';
import 'screens/onboarding_screen.dart';
import 'services/notification_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final p = await SharedPreferences.getInstance();
  ThemeStore.index = p.getInt('theme_index') ?? 0;
  ThemeStore.nightAutoEnabled = p.getBool('night_auto') ?? false;
  final bfId = p.getString('bf_id');
  final name = p.getString('user_name');
  // v1.6: language unique id se restore hoti hai ('lang_id'); purani installs
  // me sirf ttsCode ('lang') save hai — un ke liye ttsCode fallback rakha hai.
  final langId = p.getString('lang_id');
  final langCode = p.getString('lang');
  final dobRaw = p.getString('dob');
  final dob = dobRaw == null ? null : DateTime.tryParse(dobRaw);

  Widget home = const OnboardingScreen();
  if (bfId != null && name != null) {
    final bf = kAllCompanions.firstWhere((b) => b.id == bfId, orElse: () => kBoyfriends.first);
    final lang = langId != null
        ? kLanguages.firstWhere((l) => l.id == langId, orElse: () => kLanguages.first)
        : kLanguages.firstWhere((l) => l.ttsCode == langCode, orElse: () => kLanguages.first);
    if (p.getBool('theme_manual') != true) {
      ThemeStore.index = bf.themeIndex; // jo select hai, usi ka theme
    }
    home = ChatScreen(bf: bf, userName: name, lang: lang, dob: dob);
    // Daily 8am good-morning + 10pm good-night notifications from your partner
    NotificationService.initAndSchedule(bf.name, name);
  }
  runApp(AiBoyfriendApp(home: home));
}

/// v1.7: har theme text style me bundled 'Emoji' font (Noto Emoji) ka
/// fallback — emoji phone ke system emoji font par nirbhar nahi rahenge
/// (kuch devices/emulators par blank/tofu ho jate the).
TextStyle? _withEmojiFallback(TextStyle? s) => s?.copyWith(fontFamilyFallback: const ['Emoji']);

class AiBoyfriendApp extends StatelessWidget {
  final Widget home;
  const AiBoyfriendApp({super.key, required this.home});

  @override
  Widget build(BuildContext context) {
    final base = GoogleFonts.poppinsTextTheme(ThemeData.dark().textTheme);
    final textTheme = TextTheme(
      displayLarge: _withEmojiFallback(base.displayLarge),
      displayMedium: _withEmojiFallback(base.displayMedium),
      displaySmall: _withEmojiFallback(base.displaySmall),
      headlineLarge: _withEmojiFallback(base.headlineLarge),
      headlineMedium: _withEmojiFallback(base.headlineMedium),
      headlineSmall: _withEmojiFallback(base.headlineSmall),
      titleLarge: _withEmojiFallback(base.titleLarge),
      titleMedium: _withEmojiFallback(base.titleMedium),
      titleSmall: _withEmojiFallback(base.titleSmall),
      bodyLarge: _withEmojiFallback(base.bodyLarge),
      bodyMedium: _withEmojiFallback(base.bodyMedium),
      bodySmall: _withEmojiFallback(base.bodySmall),
      labelLarge: _withEmojiFallback(base.labelLarge),
      labelMedium: _withEmojiFallback(base.labelMedium),
      labelSmall: _withEmojiFallback(base.labelSmall),
    );
    return MaterialApp(
      title: 'AI Partner — Boyfriend & Girlfriend',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        textTheme: textTheme,
        colorScheme: const ColorScheme.dark(primary: Color(0xFFFF4D8D), secondary: Color(0xFFB04DFF)),
      ),
      home: home,
    );
  }
}
