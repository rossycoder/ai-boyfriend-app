import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../glass.dart';
import '../models/boyfriend.dart';
import '../services/voice_service.dart';
import 'chat_screen.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  bool _wantGirl = false; // false = boyfriend (for girls) · true = girlfriend (for boys)
  Boyfriend? _bf;
  AppLanguage _lang = kLanguages.first;
  final _nameCtrl = TextEditingController();
  DateTime? _dob;
  bool _ageOk = false;
  final _voice = VoiceService();

  List<Boyfriend> get _list => _wantGirl ? kGirlfriends : kBoyfriends;

  Future<void> _previewVoice(Boyfriend bf) async {
    final lines = {
      'en-US': bf.isGirl ? 'Hey handsome, I have been waiting for you.' : 'Hey beautiful, I have been waiting for you.',
      'ur-PK': 'Jaan, main tumhara hi intezaar kar raha tha.',
      'hi-IN': 'Hey, main tumhara intezaar kar raha tha.',
    };
    await _voice.speak(lines[_lang.ttsCode] ?? lines['en-US']!, bf, _lang);
  }

  Future<void> _pickDob() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime(2000, 1, 1),
      firstDate: DateTime(1950),
      lastDate: DateTime.now(),
      helpText: 'Your birthday — he will wish you himself',
    );
    if (picked != null) setState(() => _dob = picked);
  }

  Future<void> _start() async {
    final name = _nameCtrl.text.trim();
    if (_bf == null || name.isEmpty || !_ageOk) return;
    final p = await SharedPreferences.getInstance();
    await p.setString('bf_id', _bf!.id);
    await p.setInt('theme_index', _bf!.themeIndex); // selected companion ka theme
    await p.setBool('theme_manual', false);
    ThemeStore.index = _bf!.themeIndex;
    await p.setString('user_name', name);
    await p.setString('lang', _lang.ttsCode);
    if (_dob != null) await p.setString('dob', _dob!.toIso8601String());
    if (!mounted) return;
    Navigator.of(context).pushReplacement(MaterialPageRoute(
      builder: (_) => ChatScreen(bf: _bf!, userName: name, lang: _lang, dob: _dob),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GlassBackground(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(18, 22, 18, 24),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('AI Partner', style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w800)),
              const Text('Choose your person. They remember you, talk to you, send GIFs, and their voice... just listen.',
                  style: TextStyle(color: Colors.white70, fontSize: 14.5, height: 1.4)),
              const SizedBox(height: 14),
              // Boyfriend / Girlfriend switch
              GlassCard(
                padding: const EdgeInsets.all(8),
                child: Row(
                  children: [
                    Expanded(
                      child: _toggleBtn('💙 Boyfriend', 'For girls', !_wantGirl, () => setState(() {
                            _wantGirl = false;
                            _bf = null;
                          })),
                    ),
                    Expanded(
                      child: _toggleBtn('💖 Girlfriend', 'For boys', _wantGirl, () => setState(() {
                            _wantGirl = true;
                            _bf = null;
                          })),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 14),
              ..._list.map((bf) => Padding(
                    padding: const EdgeInsets.only(bottom: 12),
                    child: GlassCard(
                      onTap: () => setState(() => _bf = bf),
                      padding: const EdgeInsets.all(12),
                      child: Row(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(16),
                            child: Image.asset(bf.image, width: 74, height: 74, fit: BoxFit.cover),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('${bf.name}, ${bf.age} · ${bf.tagline}',
                                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 16)),
                                Text(bf.personality, style: const TextStyle(color: Colors.white70, fontSize: 13)),
                              ],
                            ),
                          ),
                          IconButton(
                            tooltip: 'Hear voice',
                            onPressed: () => _previewVoice(bf),
                            icon: Icon(Icons.play_circle_fill, color: ThemeStore.active.accentA, size: 30),
                          ),
                          if (_bf?.id == bf.id)
                            Icon(Icons.favorite, color: ThemeStore.active.accentA)
                          else
                            const Icon(Icons.favorite_border, color: Colors.white38),
                        ],
                      ),
                    ),
                  )),
              GlassCard(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Your name', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _nameCtrl,
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        hintText: 'What should they call you?',
                        hintStyle: const TextStyle(color: Colors.white54),
                        filled: true,
                        fillColor: Colors.white.withOpacity(0.10),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
                      ),
                    ),
                    const SizedBox(height: 14),
                    const Text('Language — they chat & speak in it', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 8),
                    DropdownButtonFormField<AppLanguage>(
                      value: _lang,
                      dropdownColor: const Color(0xFF2A1745),
                      style: const TextStyle(color: Colors.white),
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Colors.white.withOpacity(0.10),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
                      ),
                      items: kLanguages.map((l) => DropdownMenuItem(value: l, child: Text(l.label))).toList(),
                      onChanged: (v) => setState(() => _lang = v ?? _lang),
                    ),
                    const SizedBox(height: 14),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: const Icon(Icons.cake, color: Colors.white),
                      title: Text(
                        _dob == null ? 'Add your birthday (optional)' : 'Birthday: ${_dob!.day}/${_dob!.month} — they will wish you 🎂',
                        style: const TextStyle(color: Colors.white, fontSize: 14),
                      ),
                      subtitle: const Text('So your partner can wish you at midnight', style: TextStyle(color: Colors.white54, fontSize: 12)),
                      onTap: _pickDob,
                    ),
                    CheckboxListTile(
                      value: _ageOk,
                      onChanged: (v) => setState(() => _ageOk = v ?? false),
                      controlAffinity: ListTileControlAffinity.leading,
                      contentPadding: EdgeInsets.zero,
                      title: const Text('I am 18 or older', style: TextStyle(color: Colors.white, fontSize: 13.5)),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16),
              GlassButton(
                label: _bf == null ? 'Pick your partner first' : 'Start chatting with ${_bf!.name}',
                icon: Icons.favorite,
                onTap: (_bf != null && _ageOk) ? _start : null,
              ),
              const SizedBox(height: 10),
              const Center(
                child: Text('Free · No sign-up · Chats stay on your phone · Daily good-morning at 8am',
                    style: TextStyle(color: Colors.white54, fontSize: 12)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _toggleBtn(String title, String sub, bool selected, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: selected ? LinearGradient(colors: [ThemeStore.active.accentA, ThemeStore.active.accentB]) : null,
          color: selected ? null : Colors.transparent,
        ),
        child: Column(
          children: [
            Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15)),
            Text(sub, style: const TextStyle(color: Colors.white70, fontSize: 11.5)),
          ],
        ),
      ),
    );
  }
}
