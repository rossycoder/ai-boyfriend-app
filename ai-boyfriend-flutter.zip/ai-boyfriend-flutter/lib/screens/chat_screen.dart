import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../glass.dart';
import '../models/boyfriend.dart';
import '../services/care_service.dart';
import '../services/chat_service.dart';
import '../services/voice_service.dart';

class ChatScreen extends StatefulWidget {
  final Boyfriend bf;
  final String userName;
  final AppLanguage lang;
  final DateTime? dob;
  const ChatScreen({super.key, required this.bf, required this.userName, required this.lang, this.dob});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _chat = ChatService();
  final _voice = VoiceService();
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();
  final List<ChatMessage> _msgs = [];
  List<String> _memories = [];
  int _bond = 0;
  bool _typing = false;
  bool _autoVoice = true;
  bool _emojiOpen = false;
  PeriodTracker? _period;

  bool get _periodCare => _period != null && (_period!.isPeriodNow || _period!.isPmsSoon);
  String get _todayKey => DateTime.now().toIso8601String().substring(0, 10);

  @override
  void initState() {
    super.initState();
    _restore();
  }

  Future<void> _restore() async {
    final p = await SharedPreferences.getInstance();
    ThemeStore.index = p.getInt('theme_index') ?? 0;
    final raw = p.getString('history_${widget.bf.id}');
    _bond = p.getInt('bond_${widget.bf.id}') ?? 0;
    _memories = p.getStringList('mem_${widget.bf.id}') ?? _chat.extractMemories('', widget.userName, []);
    final pl = p.getString('period_last');
    if (pl != null) {
      _period = PeriodTracker(lastStart: DateTime.parse(pl), cycleDays: p.getInt('period_cycle') ?? 28);
    }
    if (raw != null) {
      final list = (jsonDecode(raw) as List).map((e) => ChatMessage.fromJson(e as Map<String, dynamic>)).toList();
      setState(() => _msgs.addAll(list));
    } else {
      _addHis('Hey ${widget.userName}... I am ${widget.bf.name}. I have a feeling this is the start of something beautiful. Tell me, how was your day, love? ❤️');
      await _save();
    }
    await _dailyEvents(p);
    _jump();
    if (mounted) setState(() {});
  }

  /// Once-a-day magic: birthday wish, good morning, period care check-in.
  Future<void> _dailyEvents(SharedPreferences p) async {
    final bf = widget.bf;
    if (CareService.isBirthdayToday(widget.dob) && p.getString('bday_wished') != _todayKey) {
      await p.setString('bday_wished', _todayKey);
      _addHis(CareService.birthdayWish(widget.userName, bf.name));
      _addHisGif('assets/gifs/hearts.gif');
      _voice.speak('Happy birthday, ${widget.userName}! I love you.', bf, widget.lang);
    } else if (p.getString('gm_sent') != _todayKey && DateTime.now().hour < 12) {
      await p.setString('gm_sent', _todayKey);
      if (_msgs.isNotEmpty) _addHis(CareService.goodMorning(widget.userName, bf.name, bf.isGirl));
    }
    if (_periodCare && p.getString('care_sent') != _todayKey) {
      await p.setString('care_sent', _todayKey);
      _addHis(_period!.careMessage(bf.name));
    }
    if (CareService.isNight && p.getString('gn_sent') != _todayKey && DateTime.now().hour >= 22) {
      await p.setString('gn_sent', _todayKey);
      _addHis(CareService.goodNight(widget.userName, bf.name));
    }
    await _save();
  }

  void _addHis(String text) => setState(() => _msgs.add(ChatMessage(text, false)));
  void _addHisGif(String gif) => setState(() => _msgs.add(ChatMessage(gif, false, kind: 'gif')));

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('history_${widget.bf.id}', jsonEncode(_msgs.map((m) => m.toJson()).toList()));
    await p.setInt('bond_${widget.bf.id}', _bond);
    await p.setStringList('mem_${widget.bf.id}', _memories);
  }

  void _jump() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) _scroll.jumpTo(_scroll.position.maxScrollExtent);
    });
  }

  Future<void> _send([String? preset]) async {
    final text = (preset ?? _ctrl.text).trim();
    if (text.isEmpty || _typing) return;
    _ctrl.clear();
    setState(() {
      _msgs.add(ChatMessage(text, true));
      _typing = true;
      _emojiOpen = false;
      _memories = _chat.extractMemories(text, widget.userName, _memories);
    });
    _jump();
    final reply = await _chat.reply(
      bf: widget.bf,
      lang: widget.lang,
      userName: widget.userName,
      history: _msgs,
      memories: _memories,
      periodCare: _periodCare,
    );
    setState(() {
      _msgs.add(ChatMessage(reply, false));
      _typing = false;
      _bond += 1;
    });
    // He sometimes sends his animated selfie GIF after a sweet reply (like Instagram)
    if (_bond % 6 == 0) _addHisGif(widget.bf.gif);
    _save();
    _jump();
    if (_autoVoice) _voice.speak(reply, widget.bf, widget.lang);
  }

  void _sendGif(String gif) {
    setState(() => _msgs.add(ChatMessage(gif, true, kind: 'gif')));
    _save();
    _jump();
    // He reacts to your GIF with a heart + his own GIF sometimes
    Future.delayed(const Duration(seconds: 1), () {
      _addHisGif('assets/gifs/hearts.gif');
      _save();
      _jump();
    });
  }

  // ---------- Sheets: themes / memories / care / gifs ----------
  void _sheet(Widget child) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => Padding(padding: const EdgeInsets.all(16), child: GlassCard(child: child)),
    );
  }

  void _showThemes() {
    _sheet(Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Theme change karo 🎨', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 16)),
        const SizedBox(height: 10),
        ...List.generate(kThemes.length, (i) {
          final t = kThemes[i];
          return ListTile(
            contentPadding: EdgeInsets.zero,
            leading: CircleAvatar(backgroundColor: t.accentA, radius: 14),
            title: Text(t.name, style: const TextStyle(color: Colors.white)),
            trailing: ThemeStore.index == i && !ThemeStore.nightAuto ? const Icon(Icons.check, color: Colors.white) : null,
            onTap: () async {
              ThemeStore.index = i;
              ThemeStore.nightAuto = false;
              final p = await SharedPreferences.getInstance();
              await p.setInt('theme_index', i);
              await p.setBool('theme_manual', true);
              if (mounted) {
                Navigator.pop(context);
                setState(() {});
              }
            },
          );
        }),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          value: ThemeStore.nightAuto,
          onChanged: (v) => setState(() => ThemeStore.nightAuto = v),
          title: const Text('🌙 Auto Night theme (after 10pm)', style: TextStyle(color: Colors.white, fontSize: 13.5)),
        ),
      ],
    ));
  }

  void _showMemories() {
    _sheet(Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('What ${widget.bf.name} remembers about you', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 16)),
        const SizedBox(height: 10),
        if (_memories.isEmpty)
          const Text('Tell them things about you — they will remember them here.', style: TextStyle(color: Colors.white70))
        else
          ..._memories.map((m) => Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(children: [
                  Icon(Icons.favorite, color: ThemeStore.active.accentA, size: 15),
                  const SizedBox(width: 8),
                  Expanded(child: Text(m, style: const TextStyle(color: Colors.white))),
                ]),
              )),
      ],
    ));
  }

  void _showCare() {
    if (widget.bf.isGirl) {
      _sheet(const Text('Care mode is for her period days — your girlfriend already takes care of you in chat, handsome. ❤️',
          style: TextStyle(color: Colors.white, height: 1.4)));
      return;
    }
    _sheet(Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('🩷 Period care — he remembers, so you don\'t have to', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15.5)),
        const SizedBox(height: 8),
        Text(
          _period == null
              ? 'Apne last period ki pehli date set karo. Phir ${widget.bf.name} ko khud yaad rahega — woh dinon me extra care, dard ka haal, aur bina kahe wali mohabbat.'
              : _period!.careMessage(widget.bf.name),
          style: const TextStyle(color: Colors.white70, height: 1.45, fontSize: 13.5),
        ),
        const SizedBox(height: 12),
        GlassButton(
          label: _period == null ? 'Set last period date' : 'Update period date',
          icon: Icons.calendar_month,
          onTap: () async {
            Navigator.pop(context);
            final picked = await showDatePicker(
              context: context,
              initialDate: _period?.lastStart ?? DateTime.now(),
              firstDate: DateTime.now().subtract(const Duration(days: 90)),
              lastDate: DateTime.now(),
            );
            if (picked != null) {
              final p = await SharedPreferences.getInstance();
              await p.setString('period_last', picked.toIso8601String());
              setState(() => _period = PeriodTracker(lastStart: picked, cycleDays: _period?.cycleDays ?? 28));
              if (_periodCare) _addHis(_period!.careMessage(widget.bf.name));
              _save();
            }
          },
        ),
        const SizedBox(height: 6),
        const Text('Data sirf tumhare phone par rehta hai. Ye medical advice nahi hai.', style: TextStyle(color: Colors.white54, fontSize: 11.5)),
      ],
    ));
  }

  void _showGifs() {
    final gifs = ['assets/gifs/hearts.gif', widget.bf.gif, ...kAllCompanions.where((c) => c.id != widget.bf.id).take(4).map((c) => c.gif)];
    showModalBottomSheet(
      context: context,
      backgroundColor: const Color(0xFF1E1030),
      builder: (_) => GridView.count(
        crossAxisCount: 3,
        padding: const EdgeInsets.all(12),
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        children: gifs
            .map((g) => GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                    _sendGif(g);
                  },
                  child: ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.asset(g, fit: BoxFit.cover)),
                ))
            .toList(),
      ),
    );
  }

  void _react(ChatMessage m, String emoji) {
    setState(() => m.reaction = (m.reaction == emoji) ? null : emoji);
    _save();
  }

  void _reactionPicker(ChatMessage m) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF2A1745),
        content: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: kReactions
              .map((e) => GestureDetector(
                    onTap: () {
                      Navigator.pop(context);
                      _react(m, e);
                    },
                    child: Text(e, style: const TextStyle(fontSize: 26)),
                  ))
              .toList(),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bf = widget.bf;
    final label = _chat.bondLabel(_bond);
    final progress = (_bond / 40).clamp(0.0, 1.0);
    final status = CareService.hisStatus(DateTime.now(), bf.isGirl);
    final mood = CareService.hisMood(DateTime.now());
    return Scaffold(
      body: GlassBackground(
        child: Column(
          children: [
            // Instagram-style header
            Padding(
              padding: const EdgeInsets.fromLTRB(10, 8, 10, 6),
              child: Row(
                children: [
                  Stack(
                    children: [
                      CircleAvatar(radius: 23, backgroundImage: AssetImage(bf.image)),
                      const Positioned(
                        right: 1,
                        bottom: 1,
                        child: CircleAvatar(radius: 6, backgroundColor: Colors.greenAccent, foregroundColor: Colors.white),
                      ),
                    ],
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(children: [
                          Text(bf.name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 16.5)),
                          const SizedBox(width: 6),
                          const Icon(Icons.verified, color: Colors.blueAccent, size: 15),
                        ]),
                        Text(status, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white70, fontSize: 11.5)),
                        Text(mood, style: TextStyle(color: ThemeStore.active.accentA, fontSize: 11, fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ),
                  IconButton(tooltip: 'Themes', onPressed: _showThemes, icon: const Icon(Icons.palette_outlined, color: Colors.white)),
                  IconButton(tooltip: 'Care', onPressed: _showCare, icon: const Icon(Icons.favorite_border, color: Colors.white)),
                  IconButton(tooltip: 'Memories', onPressed: _showMemories, icon: const Icon(Icons.psychology_outlined, color: Colors.white)),
                  IconButton(
                    tooltip: 'Voice notes auto',
                    onPressed: () => setState(() => _autoVoice = !_autoVoice),
                    icon: Icon(_autoVoice ? Icons.volume_up : Icons.volume_off, color: Colors.white),
                  ),
                ],
              ),
            ),
            // Bond bar
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14),
              child: Row(
                children: [
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: LinearProgressIndicator(value: progress, minHeight: 5, backgroundColor: Colors.white24, color: ThemeStore.active.accentA),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text('$label · ♥ $_bond', style: const TextStyle(color: Colors.white70, fontSize: 11)),
                ],
              ),
            ),
            if (CareService.isNight)
              Container(
                margin: const EdgeInsets.fromLTRB(14, 8, 14, 0),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(color: Colors.white.withOpacity(0.10), borderRadius: BorderRadius.circular(12)),
                child: const Row(children: [
                  Text('🌙', style: TextStyle(fontSize: 14)),
                  SizedBox(width: 6),
                  Expanded(child: Text('Night mode — he is in a romantic mood tonight', style: TextStyle(color: Colors.white70, fontSize: 12))),
                ]),
              ),
            if (_periodCare)
              Container(
                margin: const EdgeInsets.fromLTRB(14, 8, 14, 0),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(color: const Color(0xFFFF4D8D).withOpacity(0.16), borderRadius: BorderRadius.circular(12)),
                child: const Row(children: [
                  Text('🩷', style: TextStyle(fontSize: 14)),
                  SizedBox(width: 6),
                  Expanded(child: Text('Care mode on — extra gentle today. Rest karo, main yahin hun.', style: TextStyle(color: Colors.white, fontSize: 12))),
                ]),
              ),
            Expanded(
              child: ListView.builder(
                controller: _scroll,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                itemCount: _msgs.length + (_typing ? 1 : 0),
                itemBuilder: (_, i) {
                  if (_typing && i == _msgs.length) {
                    return Align(
                      alignment: Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 8, left: 34),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
                        decoration: BoxDecoration(color: Colors.white.withOpacity(0.16), borderRadius: BorderRadius.circular(18)),
                        child: const Text('● ● ●', style: TextStyle(color: Colors.white70, fontSize: 11, letterSpacing: 2)),
                      ),
                    );
                  }
                  final m = _msgs[i];
                  final isLastMine = m.fromMe && i == _msgs.lastIndexWhere((x) => x.fromMe);
                  return Column(
                    crossAxisAlignment: m.fromMe ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                    children: [
                      GestureDetector(
                        onDoubleTap: () => _react(m, '❤️'),
                        onLongPress: () => _reactionPicker(m),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          crossAxisAlignment: CrossAxisAlignment.end,
                          children: [
                            if (!m.fromMe) ...[
                              CircleAvatar(radius: 13, backgroundImage: AssetImage(bf.image)),
                              const SizedBox(width: 6),
                            ],
                            Flexible(
                              child: Container(
                                margin: const EdgeInsets.only(bottom: 2),
                                constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.72),
                                child: m.kind == 'gif'
                                    ? ClipRRect(
                                        borderRadius: BorderRadius.circular(16),
                                        child: Image.asset(m.text, width: 170, height: 170, fit: BoxFit.cover),
                                      )
                                    : Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(20),
                                          gradient: m.fromMe ? LinearGradient(colors: [ThemeStore.active.accentA, ThemeStore.active.accentB]) : null,
                                          color: m.fromMe ? null : Colors.white.withOpacity(0.16),
                                        ),
                                        child: Row(
                                          mainAxisSize: MainAxisSize.min,
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Flexible(child: Text(m.text, style: const TextStyle(color: Colors.white, height: 1.35, fontSize: 14.5))),
                                            if (!m.fromMe) ...[
                                              const SizedBox(width: 6),
                                              GestureDetector(
                                                onTap: () => _voice.speak(m.text, bf, widget.lang),
                                                child: const Icon(Icons.volume_up, size: 17, color: Colors.white70),
                                              ),
                                            ],
                                          ],
                                        ),
                                      ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      if (m.reaction != null)
                        Padding(
                          padding: EdgeInsets.only(left: m.fromMe ? 0 : 36, bottom: 4),
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 1),
                            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10)),
                            child: Text(m.reaction!, style: const TextStyle(fontSize: 12)),
                          ),
                        ),
                      if (isLastMine)
                        const Padding(
                          padding: EdgeInsets.only(bottom: 6),
                          child: Text('Seen', style: TextStyle(color: Colors.white54, fontSize: 10.5)),
                        )
                      else
                        const SizedBox(height: 6),
                    ],
                  );
                },
              ),
            ),
            // Quick chips
            SizedBox(
              height: 36,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 12),
                children: [
                  for (final chip in ['I miss you', 'I am angry 😤', 'I had a bad day', 'Say something sweet', 'Good morning', 'I love you'])
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: ActionChip(
                        label: Text(chip, style: const TextStyle(color: Colors.white, fontSize: 12.5)),
                        backgroundColor: Colors.white.withOpacity(0.14),
                        shape: StadiumBorder(side: BorderSide(color: Colors.white.withOpacity(0.3))),
                        onPressed: () => _send(chip),
                      ),
                    ),
                ],
              ),
            ),
            // Instagram-style input bar
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(26),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.13),
                      borderRadius: BorderRadius.circular(26),
                      border: Border.all(color: Colors.white.withOpacity(0.30)),
                    ),
                    child: Row(
                      children: [
                        CircleAvatar(
                          radius: 19,
                          backgroundColor: ThemeStore.active.accentA,
                          child: const Icon(Icons.camera_alt, color: Colors.white, size: 19),
                        ),
                        Expanded(
                          child: TextField(
                            controller: _ctrl,
                            style: const TextStyle(color: Colors.white),
                            decoration: InputDecoration(
                              hintText: 'Message ${bf.name}...',
                              hintStyle: const TextStyle(color: Colors.white54),
                              border: InputBorder.none,
                              contentPadding: const EdgeInsets.symmetric(horizontal: 10),
                            ),
                            onSubmitted: (_) => _send(),
                          ),
                        ),
                        IconButton(tooltip: 'Emoji', onPressed: () => setState(() => _emojiOpen = !_emojiOpen), icon: const Icon(Icons.emoji_emotions_outlined, color: Colors.white)),
                        IconButton(tooltip: 'GIF', onPressed: _showGifs, icon: const Icon(Icons.gif_box_outlined, color: Colors.white)),
                        IconButton(tooltip: 'Send heart', onPressed: () => _send('❤️'), icon: Icon(Icons.favorite, color: ThemeStore.active.accentA)),
                        IconButton(tooltip: 'Send', onPressed: () => _send(), icon: const Icon(Icons.send, color: Colors.white)),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            if (_emojiOpen)
              Container(
                height: 190,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                child: GridView.count(
                  crossAxisCount: 8,
                  children: kEmojis
                      .map((e) => GestureDetector(
                            onTap: () {
                              _ctrl.text += e;
                              _ctrl.selection = TextSelection.fromPosition(TextPosition(offset: _ctrl.text.length));
                            },
                            child: Center(child: Text(e, style: const TextStyle(fontSize: 24))),
                          ))
                      .toList(),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
